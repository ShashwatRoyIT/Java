
public class Complaint {

	String complaint;
	Customer customer;
	public Complaint(String complaint, Customer customer) {
		super();
		this.complaint = complaint;
		this.customer = customer;
	}
	public Complaint() {
		super();
		// TODO Auto-generated constructor stub
	}
	public void display() {
		System.out.println("Name : "+ customer.name + " ID : "+customer.id+" Country : " + customer.country + " Complaint : " + complaint);
//		return true;
	}
}
