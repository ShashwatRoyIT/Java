import java.lang.*;
public class Customer implements Cloneable{
	String name,id,country;

	public Customer(String name, String id, String country) {
		super();
		this.name = name;
		this.id = id;
		this.country = country;
	}

	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	protected Object clone() throws CloneNotSupportedException {
		return super.clone();
	}
	

}
