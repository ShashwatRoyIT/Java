public class Exhibition extends Event{
	//write	your code here
	Integer noOfStall;

	public Exhibition(String name, String detail, String type, String ownerName, Double costPerDay, Integer noOfStall) {
		super(name, detail, type, ownerName, costPerDay);
		this.noOfStall = noOfStall;
	}

	public Exhibition() {
		super();
		// TODO Auto-generated constructor stub
	}



	
	
}