
import java.util.*;
import java.io.*;

public class Main {

	public static void main(String[] args) throws IOException, CloneNotSupportedException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

		Customer prevCos = null;

		Customer cos = null;
		List<Complaint> comlist = new ArrayList<>();
		do {
			System.out.println("Enter the customer name");

			String name = br.readLine();
			if (name.isEmpty() && prevCos != null) {
				System.out.println("Same customer");
				cos = (Customer) prevCos.clone();
			} else {
				System.out.println("Enter the id");
				String id = br.readLine();

				System.out.println("Enter the country");
				String country = br.readLine();
				cos = new Customer(name, id, country);
				prevCos = cos;
			}

			System.out.println("Enter the complaint");
			String complaint = br.readLine();

			Complaint comp = new Complaint(complaint, cos);
			comlist.add(comp);

			System.out.println("Add another complaint ??");
			String newCom = br.readLine();
			if (newCom.equalsIgnoreCase("yes")) {

				System.out.println("jo");
				continue;
			} else {
				System.out.println("NO jo");
				break;
			}

		} while (true);

		System.out.println("Complaint Details");
		for (Complaint co : comlist) {
			co.display();
		}

	}

}

// import java.util.*;
// import java.io.*;
// import java.time.*;
// import java.time.LocalDate;
// import java.time.format.DateTimeFormatter;
// import java.time.temporal.ChronoUnit;
//
// public class Main {
// public static void main(String args[]) throws Exception{
// //write your code here
// BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
// System.out.println("Enter your choice:\n"
// + "1.Exhibition event\n"
// + "2.Stage event");
// Integer choice = Integer.parseInt(br.readLine());
// double gst;
// if(choice ==1) {
//
// System.out.println("Enter the details of exhibition:");
// String str[] = br.readLine().split(",");
//
// Event event = new
// Exhibition(str[0],str[1],str[2],str[3],Double.parseDouble(str[4]),Integer.parseInt(str[5]));
// System.out.println("Enter the starting date of the event:");
// String date1 = br.readLine();
//
// System.out.println("Enter the ending date of the event:");
// String date2 = br.readLine();
//
// LocalDate d1 =
// LocalDate.parse(date1,DateTimeFormatter.ofPattern("dd-MM-yyyy"));
//
// LocalDate d2 = LocalDate.parse(date2,
// DateTimeFormatter.ofPattern("dd-MM-yyyy"));
//
//// long days = d1.until(d2,ChronoUnit.DAYS);
// long day = ChronoUnit.DAYS.between(d1, d2);
//
// gst = (day*event.getCostPerDay())*0.05;
// }
// else {
// System.out.println("Enter the details of stage event:");
// String str[] = br.readLine().split(",");
//
// Event event = new
// StageEvent(str[0],str[1],str[2],str[3],Double.parseDouble(str[4]),Integer.parseInt(str[5]));
// System.out.println("Enter the starting date of the event:");
// String date1 = br.readLine();
//
// System.out.println("Enter the ending date of the event:");
// String date2 = br.readLine();
//
// LocalDate d1 =
// LocalDate.parse(date1,DateTimeFormatter.ofPattern("dd-MM-yyyy"));
//
// LocalDate d2 = LocalDate.parse(date2,
// DateTimeFormatter.ofPattern("dd-MM-yyyy"));
//
//// long days = d1.until(d2,ChronoUnit.DAYS);
// long day = ChronoUnit.DAYS.between(d1, d2);
// gst = (day*event.getCostPerDay())*0.15;
//
// }
//
//
//
//
//
// System.out.println("The GST to be paid is Rs."+gst);
//
// }
// }
