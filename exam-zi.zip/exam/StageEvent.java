public class StageEvent extends Event{
	//write your code here
	Integer noOfSeats;


	public StageEvent() {
		super();
		// TODO Auto-generated constructor stub
	}

	public StageEvent(String name, String detail, String type, String ownerName, Double costPerDay) {
		super(name, detail, type, ownerName, costPerDay);
		// TODO Auto-generated constructor stub
	}

	public StageEvent(String name, String detail, String type, String ownerName, Double costPerDay, Integer noOfSeats) {
		super(name, detail, type, ownerName, costPerDay);
		this.noOfSeats = noOfSeats;
	}
	
	
}
